from pathlib import Path
from PySide6.QtCore import Qt, QSize, QUrl, QPoint
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import QToolButton, QMenu, QFileDialog, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QListWidget, QSlider, QCheckBox, QMessageBox

class Shortcut(QToolButton):
    def __init__(self, shell, name, key):
        super().__init__(shell.desktop.viewport()); self.shell=shell; self.key=key; self.origin=None; self.dragging=False
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu); self.customContextMenuRequested.connect(self.menu_at)
    def mousePressEvent(self,e):
        if e.button()==Qt.MouseButton.LeftButton: self.origin=e.globalPosition().toPoint(); self.start=self.pos(); self.dragging=False
        super().mousePressEvent(e)
    def mouseMoveEvent(self,e):
        if self.origin is not None and e.buttons() & Qt.MouseButton.LeftButton:
            delta=e.globalPosition().toPoint()-self.origin
            if delta.manhattanLength()>8: self.dragging=True; self.setDown(False)
            if self.dragging:
                self.move(self.shell.clamp_icon(self.start+delta,self)); return
        super().mouseMoveEvent(e)
    def mouseReleaseEvent(self,e):
        self.origin=None
        if self.dragging:
            self.dragging=False; self.setDown(False); self.shell.settings.setValue('position/'+self.key,[self.x(),self.y()]); return
        super().mouseReleaseEvent(e)
    def menu_at(self,p):
        m=QMenu(self); m.addAction('Выбрать свою иконку',self.choose_icon); m.addAction('Вернуть стандартную иконку',self.reset_icon); m.addAction('Вернуть позицию',self.reset_pos); m.exec(self.mapToGlobal(p))
    def choose_icon(self):
        p,_=QFileDialog.getOpenFileName(self,'Иконка',str(Path.home()),'Изображения (*.png *.jpg *.ico *.svg *.webp)')
        if p and not QIcon(p).isNull(): self.shell.settings.setValue('custom_icon/'+self.key,p); self.setIcon(QIcon(p))
    def reset_icon(self):
        self.shell.settings.remove('custom_icon/'+self.key); self.setIcon(self.default_icon)
    def reset_pos(self):
        self.shell.settings.remove('position/'+self.key); self.shell.update_icons()

class Music(QWidget):
    def __init__(self):
        super().__init__(); from PySide6.QtMultimedia import QMediaPlayer,QAudioOutput
        self.player=QMediaPlayer(self); self.audio=QAudioOutput(self); self.player.setAudioOutput(self.audio); self.audio.setVolume(.5)
        self.files=[]; l=QVBoxLayout(self); l.addWidget(QLabel('chebuMusic — локальные аудиофайлы')); self.list=QListWidget(); l.addWidget(self.list); self.status=QLabel('Выбери музыку'); l.addWidget(self.status)
        r=QHBoxLayout(); l.addLayout(r)
        for title,fn in [('Добавить',self.add),('▶',self.play),('Пауза',self.player.pause),('Стоп',self.player.stop),('Следующая',self.next)]:
            b=QPushButton(title); b.clicked.connect(fn); r.addWidget(b)
        self.seek=QSlider(Qt.Orientation.Horizontal); l.addWidget(self.seek); self.seek.sliderMoved.connect(self.player.setPosition); self.player.durationChanged.connect(lambda n:self.seek.setRange(0,n)); self.player.positionChanged.connect(self.seek.setValue)
        volume=QSlider(Qt.Orientation.Horizontal); volume.setRange(0,100); volume.setValue(50); volume.valueChanged.connect(lambda n:self.audio.setVolume(n/100)); l.addWidget(QLabel('Громкость')); l.addWidget(volume)
        self.list.itemDoubleClicked.connect(lambda _:self.play()); self.player.errorOccurred.connect(lambda *args:self.status.setText(self.player.errorString())); self.player.mediaStatusChanged.connect(lambda s:self.next() if s==QMediaPlayer.MediaStatus.EndOfMedia else None)
    def add(self):
        paths,_=QFileDialog.getOpenFileNames(self,'Музыка',str(Path.home()),'Аудио (*.mp3 *.wav *.flac *.ogg *.m4a *.aac)'); self.files.extend(paths); self.list.addItems([Path(p).name for p in paths]);
        if self.list.currentRow()<0 and self.files: self.list.setCurrentRow(0)
    def play(self):
        i=self.list.currentRow()
        if i>=0:
            url=QUrl.fromLocalFile(self.files[i]);
            if self.player.source()!=url: self.player.setSource(url)
            self.status.setText(Path(self.files[i]).name); self.player.play()
    def next(self):
        i=self.list.currentRow()+1
        if i<len(self.files): self.list.setCurrentRow(i); self.play()
        else: self.player.stop()
