import sys, ast, operator, datetime, json, os
from extras import Trash, open_target
from experience import Shortcut, Music
from chebu13 import Cloud, Game, Assistant, Video, Screenshots, Paint, Monitor, LockScreen
from chebu14 import FocusTimer, StickyNotes
from chebu16 import Spotlight, SafeTerminal, GameHub, LiveWidgets, Recovery
from pathlib import Path
from PySide6.QtCore import QSize, Qt, QTimer, QSettings, QUrl, QDir, QPropertyAnimation, QPoint
from PySide6.QtGui import QColor, QBrush, QLinearGradient, QDesktopServices, QShortcut, QKeySequence, QPixmap, QIcon
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QLabel,QPushButton,QLineEdit,QPlainTextEdit,QFileDialog,QMessageBox,QComboBox,QMdiArea,QMdiSubWindow,QMenu,QTreeView,QCalendarWidget,QInputDialog,QListWidget,QListWidgetItem,QDialog,QScrollArea,QToolButton,QStyle,QCheckBox,QSlider,QGraphicsOpacityEffect,QFrame)

try:
    from PySide6.QtWidgets import QFileSystemModel
except ImportError:
    from PySide6.QtGui import QFileSystemModel

VERSION='1.6 NovaDesk'
ASSETS=Path(__file__).parent/'assets'
OPS={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Div:operator.truediv,ast.Mod:operator.mod,ast.UAdd:operator.pos,ast.USub:operator.neg}
def calculate(s):
    if len(s)>200: raise ValueError('Слишком длинное выражение')
    def walk(n):
        if isinstance(n,ast.Constant) and type(n.value) in (float,int): return n.value
        if isinstance(n,ast.BinOp) and type(n.op) in OPS: return OPS[type(n.op)](walk(n.left),walk(n.right))
        if isinstance(n,ast.UnaryOp) and type(n.op) in OPS: return OPS[type(n.op)](walk(n.operand))
        raise ValueError('Недопустимое выражение')
    return walk(ast.parse(s,mode='eval').body)

def button(text, callback):
    b=QPushButton(text); b.clicked.connect(callback); return b

def panel():
    w=QWidget(); l=QVBoxLayout(w); l.setContentsMargins(16,16,16,16); l.setSpacing(10); return w,l

def bar(layout, items):
    r=QHBoxLayout(); layout.addLayout(r)
    for name,fn in items: r.addWidget(button(name,fn))
    r.addStretch(); return r

class Notes(QWidget):
    def __init__(self):
        super().__init__(); self.path=None; l=QVBoxLayout(self); self.editor=QPlainTextEdit(); self.editor.setPlaceholderText('Начни писать…'); bar(l,[('Новый',self.new),('Открыть',self.load),('Сохранить',lambda:self.save()),('Сохранить как',lambda:self.save(True))]); l.addWidget(self.editor)
    def confirm(self):
        if not self.editor.document().isModified(): return True
        r=QMessageBox.question(self,'Блокнот','Сохранить изменения?',QMessageBox.StandardButton.Save|QMessageBox.StandardButton.Discard|QMessageBox.StandardButton.Cancel)
        return self.save() if r==QMessageBox.StandardButton.Save else r==QMessageBox.StandardButton.Discard
    def new(self):
        if self.confirm(): self.path=None; self.editor.clear(); self.editor.document().setModified(False)
    def load(self):
        if not self.confirm(): return
        p,_=QFileDialog.getOpenFileName(self,'Открыть текст',str(Path.home()),'Текст (*.txt *.md);;Все файлы (*)')
        if p:
            try: self.editor.setPlainText(Path(p).read_text(encoding='utf-8')); self.path=p; self.editor.document().setModified(False)
            except Exception as e: QMessageBox.warning(self,'Ошибка',str(e))
    def save(self,as_new=False):
        p=self.path
        if not p or as_new: p,_=QFileDialog.getSaveFileName(self,'Сохранить',str(Path.home()/'note.txt'),'Текст (*.txt)')
        if not p:return False
        try: Path(p).write_text(self.editor.toPlainText(),encoding='utf-8'); self.path=p; self.editor.document().setModified(False); return True
        except Exception as e: QMessageBox.warning(self,'Ошибка',str(e)); return False

class AppWindow(QMdiSubWindow):
    def closeEvent(self,e):
        w=self.widget()
        if isinstance(w,Notes) and not w.confirm(): e.ignore(); return
        super().closeEvent(e)

class Desktop(QMdiArea):
    def __init__(self):
        super().__init__(); self.dark=True; self.accent='#65E4C2'; self.wallpaper=''; self.pix=QPixmap(); self.show_brand=True
    def paintEvent(self,e):
        from PySide6.QtGui import QPainter,QFont
        super().paintEvent(e)
        p=QPainter(self.viewport()); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r=self.viewport().rect(); g=QLinearGradient(0,0,r.width(),r.height()); g.setColorAt(0,QColor('#10182d' if self.dark else '#e4efff')); g.setColorAt(1,QColor('#254b55' if self.dark else '#b5e4dc')); p.fillRect(r,g)
        if not self.pix.isNull():
            image=self.pix.scaled(r.size(),Qt.AspectRatioMode.KeepAspectRatioByExpanding,Qt.TransformationMode.SmoothTransformation); p.drawPixmap((r.width()-image.width())//2,(r.height()-image.height())//2,image)
            p.fillRect(r,QColor(0,0,0,70))
        if not self.show_brand: p.end(); return
        p.setPen(QColor('#ffffff' if not self.pix.isNull() else (self.accent if self.dark else '#184e55'))); p.setFont(QFont('Segoe UI',42,QFont.Weight.Bold)); p.drawText(r.adjusted(0,0,0,-40),Qt.AlignmentFlag.AlignCenter,'chebuOS'); p.setFont(QFont('Segoe UI',12)); p.drawText(r.adjusted(0,70,0,0),Qt.AlignmentFlag.AlignCenter,'Твоё пространство  /  '+VERSION); p.end()

class StartPanel(QDialog):
    def __init__(self, shell):
        super().__init__(shell, Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint)
        self.shell=shell
        self.setObjectName('startPanel')
        self.setWindowTitle('Пуск • chebuOS')
        self.resize(760, 520)
        root=QVBoxLayout(self); root.setContentsMargins(18,18,18,18); root.setSpacing(10)
        top=QHBoxLayout(); root.addLayout(top)
        brand_icon=QLabel(); brand_icon.setPixmap(QPixmap(str(ASSETS/'os.png')).scaled(28,28,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)); top.addWidget(brand_icon)
        title=QLabel('Пуск • chebuOS'); title.setObjectName('brand'); top.addWidget(title); top.addStretch()
        self.search=QLineEdit(); self.search.setPlaceholderText('Найти приложение…'); self.search.textChanged.connect(self.rebuild); root.addWidget(self.search)
        pinned=QLabel('Приложения'); pinned.setStyleSheet('font-size:16px;font-weight:600;'); root.addWidget(pinned)
        self.scroll=QScrollArea(); self.scroll.setWidgetResizable(True); self.scroll.setFrameShape(QFrame.Shape.NoFrame); root.addWidget(self.scroll,1)
        self.content=QWidget(); self.grid=QGridLayout(self.content); self.grid.setContentsMargins(4,4,4,4); self.grid.setSpacing(12); self.scroll.setWidget(self.content)
        bottom=QHBoxLayout(); root.addLayout(bottom)
        bottom.addWidget(button('Проводник', lambda:self.launch_and_close('Файлы')))
        bottom.addWidget(button('Настройки', lambda:self.launch_and_close('Настройки')))
        bottom.addWidget(button('Выключить chebuOS', self.close_shell))
        bottom.addStretch()
        self.rebuild()
    def close_shell(self):
        self.close(); self.shell.close()
    def launch_and_close(self, name):
        self.close(); self.shell.launch(name)
    def show_near(self, button):
        self.rebuild()
        self.search.clear()
        self.search.setFocus()
        pos=button.mapToGlobal(button.rect().bottomLeft())
        parent_geo=self.shell.geometry()
        x=max(parent_geo.left()+8, min(pos.x(), parent_geo.right()-self.width()-8))
        y=max(parent_geo.top()+48, parent_geo.bottom()-self.height()-48)
        self.move(x,y-self.height())
        self.show(); self.raise_()
    def rebuild(self):
        while self.grid.count():
            item=self.grid.takeAt(0)
            w=item.widget()
            if w is not None: w.deleteLater()
        query=self.search.text().casefold().strip()
        names=[n for n in self.shell.apps if query in n.casefold()]
        names.sort(key=str.casefold)
        if not names:
            label=QLabel('Ничего не найдено'); label.setStyleSheet('padding:18px; font-size:15px;'); self.grid.addWidget(label,0,0,1,3); return
        cols=4
        for i,name in enumerate(names):
            b=QToolButton()
            b.setText(name)
            b.setIcon(self.shell.app_icon(name, large=True))
            b.setIconSize(QSize(54,54))
            b.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
            b.setMinimumSize(150,104)
            b.setStyleSheet('QToolButton{background:rgba(24,40,60,190);color:white;border:1px solid rgba(255,255,255,40);border-radius:16px;padding:10px;font-size:12px;} QToolButton:hover{background:rgba(54,88,124,220);border:1px solid rgba(255,255,255,90);}')
            b.clicked.connect(lambda checked=False,n=name:self.launch_and_close(n))
            self.grid.addWidget(b, i//cols, i%cols)

class Shell(QMainWindow):
    def __init__(self, profile="Default"):
        super().__init__(); self.profile=profile; self.settings=QSettings('chebuOS','Desktop' if profile=="Default" else "Profile_"+profile); self.setWindowTitle('chebuOS • '+VERSION); self.resize(1200,780); self.setMinimumSize(760,480); self.setWindowIcon(QIcon(str(ASSETS/'os.png')))
        center=QWidget(); self.setCentralWidget(center); root=QVBoxLayout(center); root.setContentsMargins(10,10,10,10); root.setSpacing(8)
        top=QHBoxLayout(); root.addLayout(top); brand=QLabel('◈  chebuOS'); brand.setObjectName('brand'); logo=QLabel(); logo.setPixmap(QPixmap(str(ASSETS/'os.png')).scaled(36,36,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)); top.addWidget(logo); top.addWidget(brand); top.addStretch(); top.addWidget(button('Поиск приложений',self.search_apps)); top.addWidget(button('Полный экран',self.fullscreen)); top.addWidget(button('Уведомления',lambda:self.launch('Уведомления'))); top.addWidget(button('Быстрые настройки',lambda:self.launch('Быстрые настройки'))); top.addWidget(button('Выход',self.close))
        self.desktop=Desktop(); root.addWidget(self.desktop,1)
        self.apps={'Файлы':self.files,'Блокнот':Notes,'Калькулятор':self.calc,'Календарь':QCalendarWidget,'Настройки':self.preferences,'О системе':self.about,'Задачи':self.tasks,'Системная информация':self.system_info,'chebuBrowser':self.browser,'Галерея':self.gallery,'Таймер':self.stopwatch}
        self.notifications=[]
        self.apps.update({'Уведомления':self.notification_center,'chebuStore':self.store,'Виджеты':self.widget_settings,'Профили':self.profile_info,'Конвертер':self.converter,'Цветовая палитра':self.palette_app,'Генератор паролей':self.password_app})
        for name in ['Конвертер','Цветовая палитра','Генератор паролей']:
            if not self.settings.value('installed/'+name,False,type=bool): self.apps.pop(name)
        self.apps.update({'Telegram':self.telegram,'Корзина':self.trash_app,'Мои игры':self.games,'chebuGaming':self.games,'chebuMusic':Music,'Быстрые настройки':self.quick_settings})
        self.apps.update({'chebuSpotlight':lambda:Spotlight(self),'chebuTerminal':lambda:SafeTerminal(self),'chebuGame Hub':lambda:GameHub(self),'Живые виджеты':lambda:LiveWidgets(self),'chebuRecovery':lambda:Recovery(self),'Умные окна':self.window_tools,'Рабочие столы':self.workspace_tools})
        self.apps.update({'chebuDrive':Cloud,'chebuArcade':Game,'chebuAssistant':lambda:Assistant(self.launch),'chebuVideo':Video,'chebuShot':Screenshots,'chebuPaint':Paint,'chebuMonitor':Monitor,'Экран блокировки':LockScreen,'chebuFocus':FocusTimer,'chebuNotes':StickyNotes})
        self.workspace=0
        self.workspaces={0:[],1:[],2:[]}
        self.trash=Trash(Path(os.environ.get('LOCALAPPDATA',str(Path.home())))/'chebuOS'/'Trash')
        try: self.game_links=json.loads(self.settings.value('game_links','[]'))
        except (ValueError,TypeError): self.game_links=[]
        self.shortcuts=[]; self.create_icons()
        self.widget_box=QLabel(self.desktop.viewport()); self.widget_box.setStyleSheet('background:#182a40;color:white;border-radius:14px;padding:13px;font-size:16px'); self.widget_box.setFixedSize(210,94); self.widget_box.show()
        dock=QHBoxLayout(); root.addLayout(dock); self.start=QPushButton('Пуск'); self.start.setIcon(QIcon(str(ASSETS/'os.png'))); dock.addWidget(self.start); self.start_panel=StartPanel(self); self.start.clicked.connect(lambda:self.start_panel.show_near(self.start))
        # Floating-style dock with application shortcuts and workspace buttons.
        self.dock_frame=QFrame(); self.dock_frame.setObjectName('chebuDock')
        self.dock_frame.setStyleSheet('QFrame#chebuDock {background:rgba(35,55,83,230);border:1px solid #52718d;border-radius:18px;padding:3px;}')
        dock_l=QHBoxLayout(self.dock_frame);dock_l.setContentsMargins(8,4,8,4);dock_l.setSpacing(7)
        for name in ['chebuBrowser','Файлы','chebuGame Hub','Блокнот','chebuSpotlight','Настройки']:
            b=QToolButton();b.setIcon(self.app_icon(name));b.setIconSize(QSize(29,29));b.setToolTip(name);b.setMinimumSize(44,42)
            b.clicked.connect(lambda checked=False,n=name:self.launch(n) if n!='chebuSpotlight' else self.show_spotlight())
            dock_l.addWidget(b)
        dock.addWidget(self.dock_frame)
        self.workspace_buttons=[]
        for i in range(3):
            b=QPushButton(f' {i+1} ');b.setToolTip(f'Рабочий стол {i+1}');b.clicked.connect(lambda checked=False,k=i:self.switch_workspace(k));dock.addWidget(b);self.workspace_buttons.append(b)

        dock.addStretch(); self.running=QComboBox(); self.running.setMinimumWidth(125); self.running.activated.connect(self.switch_window); dock.addWidget(self.running); self.clock=QLabel(); dock.addWidget(self.clock); self.timer=QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(1000); self.tick(); self.desktop.subWindowActivated.connect(lambda _:self.update_running())
        self.window_menu=QMenu('Окна',self); self.window_menu.aboutToShow.connect(self.refresh_windows); self.menuBar().addMenu(self.window_menu)
        QShortcut(QKeySequence('F11'),self).activated.connect(self.fullscreen); QShortcut(QKeySequence('Ctrl+Alt+N'),self).activated.connect(lambda:self.launch('Блокнот'))
        self.apply_theme(self.settings.value('theme','dark'),self.settings.value('accent','#65E4C2')); self.set_wallpaper(self.settings.value('wallpaper',str(Path(__file__).parent/'wallpapers'/'Galaxy.png'))); self.toggle_brand(self.settings.value('brand',False,type=bool)); self.update_running(); self.update_icons(); self.notify('Добро пожаловать, '+profile); QShortcut(QKeySequence('Ctrl+K'),self).activated.connect(self.show_spotlight); QShortcut(QKeySequence('Alt+Space'),self).activated.connect(self.show_spotlight); self.spotlight_dialog=None; self.update_workspace_buttons()
    def app_icon(self,name, large=False):
        mapping={
            'chebuBrowser': ASSETS/'browser.png',
            'Корзина': ASSETS/'trash.png',
            'chebuOS': ASSETS/'os.png',
        }
        if name in mapping and mapping[name].is_file():
            return QIcon(str(mapping[name]))
        st=QStyle.StandardPixmap
        standard={
            'Файлы': st.SP_DirIcon,
            'Блокнот': st.SP_FileIcon,
            'Галерея': st.SP_DialogOpenButton,
            'Настройки': st.SP_FileDialogDetailedView,
            'Калькулятор': st.SP_FileDialogContentsView,
            'Telegram': st.SP_MessageBoxInformation,
            'chebuStore': st.SP_DriveHDIcon,
            'Мои игры': st.SP_ComputerIcon,
            'chebuGaming': st.SP_ComputerIcon,
            'chebuMusic': st.SP_MediaPlay,
            'chebuArcade': st.SP_ComputerIcon,
            'chebuDrive': st.SP_DriveHDIcon,
            'chebuPaint': st.SP_FileDialogContentsView,
            'chebuAssistant': st.SP_MessageBoxQuestion,
            'chebuFocus': st.SP_BrowserStop,
            'chebuNotes': st.SP_FileIcon,
            'chebuVideo': st.SP_MediaPlay,
            'chebuShot': st.SP_DialogSaveButton,
            'chebuMonitor': st.SP_ComputerIcon,
            'Экран блокировки': st.SP_MessageBoxWarning,
            'О системе': st.SP_TitleBarMenuButton,
            'Системная информация': st.SP_ComputerIcon,
            'Уведомления': st.SP_MessageBoxInformation,
            'Быстрые настройки': st.SP_FileDialogDetailedView,
            'Профили': st.SP_DirHomeIcon,
            'Конвертер': st.SP_ArrowRight,
            'Цветовая палитра': st.SP_DialogOpenButton,
            'Генератор паролей': st.SP_DialogResetButton,
            'Календарь': st.SP_FileDialogInfoView,
            'Таймер': st.SP_BrowserReload,
            'chebuFocus': st.SP_BrowserStop,
            'chebuSpotlight': st.SP_FileDialogListView,
            'chebuTerminal': st.SP_ComputerIcon,
            'chebuGame Hub': st.SP_ComputerIcon,
            'chebuRecovery': st.SP_DialogSaveButton,
            'Живые виджеты': st.SP_FileDialogInfoView,
            'Умные окна': st.SP_TitleBarMaxButton,
            'Рабочие столы': st.SP_ComputerIcon,
        }
        pix=standard.get(name, st.SP_FileIcon)
        return self.style().standardIcon(pix)

    def create_icons(self):
        for old in self.shortcuts: old.hide(); old.deleteLater()
        self.shortcuts=[]
        st=QStyle.StandardPixmap
        entries=[(n,self.app_icon(n),lambda n=n:self.launch(n)) for n in ['chebuBrowser','Файлы','Блокнот','Галерея','Настройки','Калькулятор','Telegram','Корзина','chebuStore','Мои игры','chebuMusic','chebuArcade','chebuDrive','chebuPaint','chebuAssistant','chebuFocus','chebuNotes','chebuSpotlight','chebuGame Hub','chebuTerminal','chebuRecovery']]
        for j,g in enumerate(self.game_links): entries.append((g['name'],self.style().standardIcon(st.SP_FileIcon),lambda p=g['path']:open_target(self,p)))
        for i,(name,ico,fn) in enumerate(entries):
            key=str(i) if i<11 else name+'_'+str(i); b=Shortcut(self,name,key); b.default_icon=ico; custom=self.settings.value('custom_icon/'+key,''); ico=QIcon(custom) if custom and Path(custom).is_file() else ico; b.setText(name[:20]); b.setToolTip(name); b.setIcon(ico); b.setIconSize(QSize(42,42)); b.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon); b.setStyleSheet('QToolButton {background:rgba(15,25,40,150);color:white;border:1px solid rgba(255,255,255,60);border-radius:12px;font-size:11px;} QToolButton:hover {background:rgba(50,100,120,200);border:1px solid white;}'); b.clicked.connect(lambda checked=False,f=fn:f()); self.shortcuts.append(b)
        self.update_icons()
    def clamp_icon(self,pos,b):
        v=self.desktop.viewport(); return QPoint(max(0,min(pos.x(),v.width()-b.width())),max(0,min(pos.y(),v.height()-b.height())))
    def update_icons(self):
        size=self.settings.value('icon_size',42,type=int); width=max(100,size+30); height=size+36
        rows=max(1,(self.desktop.viewport().height()-12)//height); cols=max(1,(self.desktop.viewport().width()-12)//width)
        for i,b in enumerate(self.shortcuts):
            if b.dragging: continue
            b.resize(width-6,height-6); b.setIconSize(QSize(size,size)); pos=self.settings.value('position/'+b.key,None)
            if isinstance(pos,(list,tuple)) and len(pos)==2: target=QPoint(int(pos[0]),int(pos[1]))
            else: target=QPoint(8+(i//rows)*width,8+(i%rows)*height)
            b.move(self.clamp_icon(target,b)); b.setVisible(self.settings.value('icons',True,type=bool) and (i<rows*cols or pos is not None) and not self.settings.value('gaming',False,type=bool))
    def quick_settings(self):
        w,l=panel(); l.addWidget(QLabel('Быстрые настройки chebuOS')); l.addWidget(button('Сменить тему',lambda:self.apply_theme('light' if self.desktop.dark else 'dark',self.desktop.accent))); l.addWidget(button('Полный экран / окно',self.fullscreen)); l.addWidget(QLabel('Размер иконок рабочего стола')); slider=QSlider(Qt.Orientation.Horizontal); slider.setRange(28,72); slider.setValue(self.settings.value('icon_size',42,type=int)); slider.valueChanged.connect(lambda n:(self.settings.setValue('icon_size',n),self.update_icons())); l.addWidget(slider)
        for key,label,default in [('gaming','Игровой режим (скрыть иконки и виджеты, отключить сигналы и анимации)',False),('sound','Звуки уведомлений',False),('widgets','Виджеты',True),('animations','Анимации окон',True)]:
            c=QCheckBox(label); c.setChecked(self.settings.value(key,default,type=bool)); c.toggled.connect(lambda on,k=key:(self.settings.setValue(k,on),self.tick())); l.addWidget(c)
        def reset():
            self.settings.remove('position'); self.update_icons()
        l.addWidget(button('Сбросить расположение иконок',reset)); l.addWidget(button('Открыть библиотеку игр',lambda:self.launch('chebuGaming'))); l.addStretch(); return w
    def telegram(self):
        w,l=panel(); l.addWidget(QLabel('Telegram — официальный клиент или веб-версия'))
        l.addWidget(button('Открыть Telegram Web',lambda:self.open_web('https://web.telegram.org/')))
        l.addWidget(button('Telegram Desktop — официальный сайт',lambda:QDesktopServices.openUrl(QUrl('https://desktop.telegram.org/'))))
        l.addWidget(button('Запустить установленный Telegram',lambda:QDesktopServices.openUrl(QUrl('tg://resolve?domain=telegram'))))
        l.addStretch(); return w
    def open_web(self,url):
        self.launch('chebuBrowser'); w=self.desktop.activeSubWindow()
        if w: w.widget().current().setUrl(QUrl(url))
    def games(self):
        w,l=panel(); label=QLabel('Добавь ярлык установленной игры (.exe, .lnk, .url). Файлы игры не копируются.'); label.setWordWrap(True); l.addWidget(label); items=QListWidget(); l.addWidget(items)
        def refresh():
            items.clear(); items.addItems([g['name']+' — '+g['path'] for g in self.game_links]); self.settings.setValue('game_links',json.dumps(self.game_links,ensure_ascii=False)); self.create_icons()
        def add():
            p,_=QFileDialog.getOpenFileName(w,'Выбери ярлык игры',str(Path.home()),'Игры и ярлыки (*.exe *.lnk *.url)')
            if not p:return
            n,ok=QInputDialog.getText(w,'Ярлык','Название игры:',text=Path(p).stem)
            if ok and n.strip(): self.game_links.append({'name':n.strip()[:60],'path':p}); refresh()
        def remove():
            i=items.currentRow()
            if i>=0: self.game_links.pop(i); refresh()
        def run():
            i=items.currentRow()
            if i>=0: open_target(w,self.game_links[i]['path'])
        bar(l,[('Добавить игру',add),('Запустить',run),('Убрать ярлык',remove)]); items.addItems([g['name']+' — '+g['path'] for g in self.game_links]); items.itemDoubleClicked.connect(lambda _:run()); return w
    def trash_app(self):
        w,l=panel(); label=QLabel('Корзина chebuOS: файлы можно вернуть на прежнее место. Это отдельная корзина, не корзина Windows.'); label.setWordWrap(True); l.addWidget(label); items=QListWidget(); l.addWidget(items); entries=[]
        def refresh():
            entries[:]=self.trash.entries(); items.clear(); items.addItems([p for _,p in entries])
        def add():
            p,_=QFileDialog.getOpenFileName(w,'Переместить файл в корзину',str(Path.home()))
            if not p:return
            if QMessageBox.question(w,'Корзина','Переместить выбранный файл в корзину chebuOS?')!=QMessageBox.StandardButton.Yes:return
            try: self.trash.put(p); refresh()
            except Exception as e: QMessageBox.warning(w,'Корзина',str(e))
        def restore():
            i=items.currentRow()
            if i<0:return
            try: self.trash.restore(*entries[i]); refresh()
            except Exception as e: QMessageBox.warning(w,'Корзина',str(e))
        bar(l,[('Переместить файл',add),('Восстановить',restore),('Обновить',refresh)]); refresh(); return w
    def toggle_icons(self,on):
        self.settings.setValue('icons',on); self.update_icons()
    def toggle_brand(self,on):
        self.desktop.show_brand=on; self.settings.setValue('brand',on); self.desktop.viewport().update()
    def browser(self):
        from browser import Browser
        return Browser()
    def gallery(self):
        w,l=panel(); l.addWidget(QLabel('Выбери обои chebuOS')); grid=QGridLayout(); l.addLayout(grid)
        for i,p in enumerate(sorted((Path(__file__).parent/'wallpapers').glob('*.png'))):
            b=QToolButton(); from PySide6.QtGui import QIcon
            b.setIcon(QIcon(str(p))); b.setIconSize(QSize(170,96)); b.setText(p.stem); b.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon); b.clicked.connect(lambda checked=False,path=str(p):self.set_wallpaper(path)); grid.addWidget(b,i//2,i%2)
        l.addWidget(button('Своя картинка',self.choose_wallpaper)); l.addStretch(); return w
    def stopwatch(self):
        import time
        w,l=panel(); display=QLabel('00:00.0'); display.setObjectName('brand'); l.addWidget(display); timer=QTimer(w); timer.setInterval(100); state={'start':None,'elapsed':0.0}
        def tick():
            t=state['elapsed']+(time.monotonic()-state['start'] if state['start'] is not None else 0); display.setText(f'{int(t//60):02d}:{t%60:04.1f}')
        def start():
            if state['start'] is None: state['start']=time.monotonic(); timer.start()
        def stop():
            if state['start'] is not None: state['elapsed']+=time.monotonic()-state['start']; state['start']=None; timer.stop(); tick()
        def reset():
            stop(); state['elapsed']=0; tick()
        timer.timeout.connect(tick); bar(l,[('Старт',start),('Пауза',stop),('Сброс',reset)]); l.addStretch(); return w
    def tick(self):
        now=datetime.datetime.now(); self.clock.setText(now.strftime('%H:%M  |  %d.%m.%Y'))
        self.widget_box.setText(now.strftime('%H:%M\n%d.%m.%Y')+'  •  '+self.profile)
        self.widget_box.move(max(0,self.desktop.viewport().width()-225),16); self.update_icons()
        self.widget_box.setVisible(self.settings.value('widgets',True,type=bool) and not self.settings.value('gaming',False,type=bool))
    def notify(self,message):
        self.notifications.append(datetime.datetime.now().strftime('%H:%M')+'  '+message)
        self.notifications=self.notifications[-100:]
        self.statusBar().showMessage(message,4000)
        if self.settings.value('sound',False,type=bool) and not self.settings.value('gaming',False,type=bool): QApplication.beep()
    def notification_center(self):
        w,l=panel(); items=QListWidget(); items.addItems(list(reversed(self.notifications))); l.addWidget(items)
        def clear(): self.notifications.clear(); items.clear()
        l.addWidget(button('Очистить',clear)); return w
    def widget_settings(self):
        w,l=panel()
        for key,label,default in [('widgets','Часы и дата на рабочем столе',True),('sound','Системный звуковой сигнал',False),('animations','Анимация открытия приложений',True)]:
            c=QCheckBox(label); c.setChecked(self.settings.value(key,default,type=bool)); c.toggled.connect(lambda on,k=key:self.settings.setValue(k,on)); l.addWidget(c)
        l.addWidget(button('Проверить уведомление',lambda:self.notify('Тестовое уведомление chebuOS'))); l.addStretch(); return w
    def profile_info(self):
        w,l=panel(); l.addWidget(QLabel('Текущий профиль: '+self.profile)); info=QLabel('Настройки и задачи разделены по профилям. Для смены профиля перезапусти chebuOS. Это не защищённые учётные записи: доступ к файлам Windows общий.'); info.setWordWrap(True); l.addWidget(info); l.addStretch(); return w
    def store(self):
        w,l=panel(); l.addWidget(QLabel('chebuStore — встроенный каталог'))
        for name,factory in [('Конвертер',self.converter),('Цветовая палитра',self.palette_app),('Генератор паролей',self.password_app)]:
            row=QHBoxLayout(); l.addLayout(row); row.addWidget(QLabel(name)); b=QPushButton('Открыть' if name in self.apps else 'Установить'); row.addWidget(b)
            def install(checked=False,n=name,f=factory,btn=b):
                if n in self.apps: self.launch(n); return
                self.apps[n]=f; self.settings.setValue('installed/'+n,True); btn.setText('Открыть'); self.notify('Установлено: '+n)
                if hasattr(self,'start_panel'): self.start_panel.rebuild()
            b.clicked.connect(install)
        l.addWidget(button('Telegram',lambda:self.launch('Telegram'))); l.addWidget(button('Мои игры',lambda:self.launch('Мои игры'))); l.addStretch(); return w
    def converter(self):
        w,l=panel(); x=QLineEdit(); x.setPlaceholderText('Число'); l.addWidget(x); units=QComboBox(); units.addItems(['км → м','м → см','кг → г','°C → °F','°F → °C']); l.addWidget(units); result=QLabel(''); l.addWidget(result)
        def run():
            try:
                v=float(x.text().replace(',','.')); result.setText(str([v*1000,v*100,v*1000,v*1.8+32,(v-32)/1.8][units.currentIndex()]))
            except ValueError: result.setText('Введи число')
        l.addWidget(button('Конвертировать',run)); l.addStretch(); return w
    def palette_app(self):
        from PySide6.QtWidgets import QColorDialog
        w,l=panel(); label=QLabel('#65E4C2'); l.addWidget(label)
        def choose():
            c=QColorDialog.getColor(QColor(label.text()),w)
            if c.isValid(): label.setText(c.name()); label.setStyleSheet('background:'+c.name()+';color:'+('#000' if c.lightness()>128 else '#fff')+';padding:20px')
        l.addWidget(button('Выбрать цвет',choose)); l.addWidget(button('Копировать HEX',lambda:QApplication.clipboard().setText(label.text()))); l.addStretch(); return w
    def password_app(self):
        import secrets,string
        w,l=panel(); output=QLineEdit(); output.setReadOnly(True); l.addWidget(output); l.addWidget(button('Создать пароль',lambda:output.setText(''.join(secrets.choice(string.ascii_letters+string.digits+'!@#$%') for _ in range(20))))); l.addWidget(button('Копировать',lambda:QApplication.clipboard().setText(output.text()))); l.addStretch(); return w
    def show_spotlight(self):
        if self.spotlight_dialog is None:
            self.spotlight_dialog=Spotlight(self)
        self.spotlight_dialog.launch_search()
    def persist_games(self):
        self.settings.setValue('game_links',json.dumps(self.game_links,ensure_ascii=False))
        self.create_icons()
    def switch_workspace(self,index):
        if index not in self.workspaces or index==self.workspace:return
        for w in list(self.workspaces[self.workspace]):
            if w in self.desktop.subWindowList():w.hide()
        self.workspace=index
        for w in list(self.workspaces[index]):
            if w in self.desktop.subWindowList():w.show()
        self.update_running();self.update_workspace_buttons()
        self.notify('Рабочий стол '+str(index+1))
    def update_workspace_buttons(self):
        for i,b in enumerate(getattr(self,'workspace_buttons',[])):
            b.setStyleSheet('font-weight:bold;background:#427c8b;color:white;' if i==self.workspace else '')
    def workspace_tools(self):
        w,l=panel();l.addWidget(QLabel('Виртуальные рабочие столы внутри chebuOS'))
        l.addWidget(QLabel('Каждый рабочий стол показывает свой набор окон.'))
        bar(l,[(f'Стол {i+1}',lambda k=i:self.switch_workspace(k)) for i in range(3)])
        l.addStretch();return w
    def window_tools(self):
        w,l=panel();l.addWidget(QLabel('Умные окна — текущий рабочий стол'))
        l.addWidget(button('Два окна рядом',self.snap_two))
        l.addWidget(button('До четырёх окон',self.snap_four))
        l.addWidget(button('Каскад',self.desktop.cascadeSubWindows))
        l.addStretch();return w
    def visible_workspace_windows(self):
        return [w for w in self.workspaces[self.workspace]
                if w in self.desktop.subWindowList() and not w.isHidden()]
    def snap_two(self):self.tile_current(2)
    def snap_four(self):self.tile_current(4)
    def tile_current(self,max_count):
        wins=self.visible_workspace_windows()[:max_count]
        if not wins:return
        area=self.desktop.viewport().rect()
        count=len(wins)
        cols=2 if count>1 else 1
        rows=2 if count>2 else 1
        width=max(150,(area.width()-20)//cols)
        height=max(120,(area.height()-20)//rows)
        for idx,win in enumerate(wins):
            if win.isMinimized():win.showNormal()
            win.setGeometry((idx%cols)*width,(idx//cols)*height,width,height)
    def fullscreen(self): self.showNormal() if self.isFullScreen() else self.showFullScreen()
    def refresh_windows(self):
        self.window_menu.clear(); self.window_menu.addAction('Каскад',self.desktop.cascadeSubWindows); self.window_menu.addAction('Плитка',self.desktop.tileSubWindows); self.window_menu.addSeparator()
        for w in self.visible_workspace_windows(): self.window_menu.addAction(w.windowTitle(),lambda checked=False,s=w:(s.showNormal() if s.isMinimized() else None,self.desktop.setActiveSubWindow(s)))
    def launch(self,name):
        w=AppWindow(); w.setWidget(self.apps[name]()); w.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose); w.setWindowTitle(name); self.desktop.addSubWindow(w); self.workspaces[self.workspace].append(w); w.resize(min(1000 if name=='chebuBrowser' else 650,self.desktop.width()-30),min(680 if name=='chebuBrowser' else 450,self.desktop.height()-30)); w.show(); self.desktop.setActiveSubWindow(w); self.update_running(); w.destroyed.connect(lambda *_:QTimer.singleShot(0,self.update_running))
        if self.settings.value('animations',True,type=bool) and name!='chebuBrowser' and not self.settings.value('gaming',False,type=bool):
            effect=QGraphicsOpacityEffect(w); w.setGraphicsEffect(effect); animation=QPropertyAnimation(effect,b'opacity',w); animation.setDuration(180); animation.setStartValue(0.25); animation.setEndValue(1.0); animation.finished.connect(lambda:w.setGraphicsEffect(None)); w._animation=animation; animation.start()
        self.notify('Открыто: '+name)
    def files(self):
        w,l=panel(); path=QLineEdit(str(Path.home())); l.addWidget(path); tree=QTreeView(); model=QFileSystemModel(tree); model.setRootPath(str(Path.home())); tree.setModel(model); tree.setRootIndex(model.index(str(Path.home()))); tree.setColumnWidth(0,260); l.addWidget(tree)
        def navigate(p):
            if Path(p).is_dir(): model.setRootPath(p); tree.setRootIndex(model.index(p)); path.setText(p)
            else: QMessageBox.warning(w,'Файлы','Папка не найдена')
        def activate(i):
            p=model.filePath(i)
            if model.isDir(i):navigate(p)
            else: QDesktopServices.openUrl(QUrl.fromLocalFile(p))
        path.returnPressed.connect(lambda:navigate(path.text())); tree.doubleClicked.connect(activate); bar(l,[('Домой',lambda:navigate(str(Path.home()))),('Вверх',lambda:navigate(str(Path(path.text()).parent))),('Выбрать папку',lambda:choose())])
        def choose():
            p=QFileDialog.getExistingDirectory(w,'Папка',path.text());
            if p:navigate(p)
        return w
    def calc(self):
        w,l=panel(); inp=QLineEdit(); inp.setPlaceholderText('Например: (25 + 7) * 3'); l.addWidget(inp); result=QLabel('0'); result.setObjectName('brand'); l.addWidget(result); grid=QGridLayout(); l.addLayout(grid)
        def solve():
            try: result.setText(str(calculate(inp.text())))
            except Exception: result.setText('Ошибка выражения')
        for i,k in enumerate(['7','8','9','/','4','5','6','*','1','2','3','-','0','.','=','+','(',')','%','C']):
            def press(checked=False,key=k):
                if key=='=':solve()
                elif key=='C':inp.clear();result.setText('0')
                else:inp.insert(key)
            grid.addWidget(button(k,press),i//4,i%4)
        inp.returnPressed.connect(solve);return w
    def preferences(self):
        w,l=panel(); l.addWidget(QLabel('Оформление')); theme=QComboBox(); theme.addItems(['dark','light']); theme.setCurrentText(self.settings.value('theme','dark')); l.addWidget(theme); l.addWidget(QLabel('Акцент')); accent=QComboBox(); accent.addItems(['#65E4C2','#83B5FF','#D8A5FF','#FFC278']); accent.setCurrentText(self.settings.value('accent','#65E4C2')); l.addWidget(accent); l.addWidget(button('Применить и сохранить',lambda:self.apply_theme(theme.currentText(),accent.currentText()))); l.addWidget(button('Выбрать обои',self.choose_wallpaper)); l.addWidget(button('Стандартные обои',lambda:self.set_wallpaper(''))); l.addWidget(button('Галерея обоев',lambda:self.launch('Галерея'))); icons=QCheckBox('Иконки рабочего стола'); icons.setChecked(self.settings.value('icons',True,type=bool)); icons.toggled.connect(self.toggle_icons); l.addWidget(icons); brand=QCheckBox('Логотип на обоях'); brand.setChecked(self.desktop.show_brand); brand.toggled.connect(self.toggle_brand); l.addWidget(brand); l.addStretch();return w
    def apply_theme(self,theme,accent):
        dark=theme=='dark'; self.desktop.dark=dark; self.desktop.accent=accent; self.desktop.viewport().update(); self.settings.setValue('theme',theme);self.settings.setValue('accent',accent);self.settings.sync()
        bg,fg,surface,border=('#111827','#E8EDF8','#202D42','#394A63') if dark else ('#EAF0F8','#182638','#FFFFFF','#BBCADD')
        self.setStyleSheet(f'''QMainWindow,QWidget {{background-color:{bg};color:{fg};font-family:Segoe UI;font-size:14px;}} QLabel#brand {{font-size:23px;font-weight:700;}} QPushButton,QComboBox,QLineEdit,QPlainTextEdit,QTreeView,QMenu {{background:{surface};color:{fg};border:1px solid {border};border-radius:7px;padding:8px;}} QPushButton:hover {{border-color:{accent};}} QPushButton:pressed {{background:{border};}} QMenu::item:selected {{background:{border};}} QMdiSubWindow {{background:{surface};}} QTreeView::item:selected {{background:{border};}}''')
    def set_wallpaper(self,path):
        pix=QPixmap(path) if path else QPixmap()
        if path and pix.isNull(): return
        self.desktop.pix=pix; self.settings.setValue('wallpaper',path); self.desktop.viewport().update()
    def choose_wallpaper(self):
        path,_=QFileDialog.getOpenFileName(self,'Выбрать обои',str(Path.home()),'Изображения (*.png *.jpg *.jpeg *.bmp *.webp)')
        if path: self.set_wallpaper(path)
    def update_running(self):
        self.running.clear(); self.running.addItem('Открытые окна')
        for w in self.visible_workspace_windows(): self.running.addItem(w.windowTitle())
    def switch_window(self,index):
        windows=self.visible_workspace_windows()
        if 0<index<=len(windows):
            w=windows[index-1]
            if w.isMinimized(): w.showNormal()
            self.desktop.setActiveSubWindow(w)
    def search_apps(self):
        dialog=QDialog(self); dialog.setWindowTitle('Поиск • chebuOS'); dialog.resize(400,380); l=QVBoxLayout(dialog)
        field=QLineEdit(); field.setPlaceholderText('Найти приложение…'); l.addWidget(field); results=QListWidget(); l.addWidget(results)
        def filter_apps(query=''):
            results.clear(); results.addItems([name for name in self.apps if query.casefold() in name.casefold()]); results.setCurrentRow(0)
        def open_app():
            item=results.currentItem()
            if item: name=item.text(); dialog.accept(); self.launch(name)
        field.textChanged.connect(filter_apps); field.returnPressed.connect(open_app); results.itemDoubleClicked.connect(lambda _:open_app()); l.addWidget(button('Открыть',open_app)); filter_apps(); field.setFocus(); dialog.exec()
    def tasks(self):
        w,l=panel(); l.addWidget(QLabel('Мои задачи')); items=QListWidget(); l.addWidget(items); entry=QLineEdit(); entry.setPlaceholderText('Новая задача'); l.addWidget(entry)
        def add_item(label,done=False):
            item=QListWidgetItem(label); item.setFlags(item.flags()|Qt.ItemFlag.ItemIsUserCheckable); item.setCheckState(Qt.CheckState.Checked if done else Qt.CheckState.Unchecked); items.addItem(item)
        def save():
            self.settings.setValue('tasks',json.dumps([[items.item(i).text(),items.item(i).checkState()==Qt.CheckState.Checked] for i in range(items.count())],ensure_ascii=False))
        try:
            for label,done in json.loads(self.settings.value('tasks','[]')): add_item(label,done)
        except (ValueError,TypeError): pass
        def add():
            if entry.text().strip(): add_item(entry.text().strip()); entry.clear(); save()
        def remove():
            if items.currentRow()>=0: items.takeItem(items.currentRow()); save()
        entry.returnPressed.connect(add); items.itemChanged.connect(lambda _:save()); bar(l,[('Добавить',add),('Удалить выбранную',remove)]); return w
    def system_info(self):
        import platform
        from PySide6 import __version__
        w,l=panel(); label=QLabel(f"chebuOS {VERSION}\nWindows / host: {platform.platform()}\nPython: {platform.python_version()}\nQt for Python: {__version__}\nArchitecture: {platform.machine()}"); label.setWordWrap(True); l.addWidget(label); l.addStretch(); return w
    def about(self):
        w,l=panel(); image=QLabel(); image.setPixmap(QPixmap(str(ASSETS/'os_full.png')).scaled(160,160,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)); l.addWidget(image); t=QLabel('chebuOS');t.setObjectName('brand');l.addWidget(t); info=QLabel(VERSION+'\nГрафическая среда для Windows\nAlt+Space / Ctrl+K — chebuSpotlight\nТри рабочих стола и управление окнами\nСтартовое меню с плитками и иконками\nPython + PySide6 / Qt\n\nF11 — полный экран\nCtrl+Alt+N — блокнот\nCtrl+K — поиск приложений\nМеню «Окна» — управление окнами\n\nНе заменяет ядро Windows.');info.setWordWrap(True);l.addWidget(info);l.addStretch();return w
    def closeEvent(self,e):
        self.desktop.closeAllSubWindows()
        if any(not w.isHidden() for w in self.desktop.subWindowList()):e.ignore()
        else:e.accept()

if __name__=='__main__':
    if os.name=='nt':
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('chebuOS.desktop.shell')
        except Exception:
            pass
    app=QApplication(sys.argv); app.setStyle('Fusion'); app.setWindowIcon(QIcon(str(ASSETS/'os.png')))
    profiles=QSettings('chebuOS','Profiles'); names=profiles.value('names',['Default']); names=[names] if isinstance(names,str) else list(names)
    name,ok=QInputDialog.getItem(None,'chebuOS — вход','Выбери профиль или введи новое имя',names,0,True)
    if not ok: sys.exit(0)
    name=name.strip()[:40] or 'Default'
    if name not in names: names.append(name); profiles.setValue('names',names)
    from PySide6.QtWidgets import QSplashScreen
    splash=QSplashScreen(QPixmap(str(ASSETS/'os_full.png')).scaled(420,420,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)); splash.show(); app.processEvents()
    shell=Shell(name); shell.show(); QTimer.singleShot(850,lambda:splash.finish(shell)); sys.exit(app.exec())
