"""chebuOS 1.6: optional shell components. No commands execute in the host shell."""
import json
import datetime
import os
from pathlib import Path
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (QApplication,QWidget,QVBoxLayout,QHBoxLayout,QLabel,
 QPushButton,QLineEdit,QTextEdit,QListWidget,QFileDialog,QMessageBox,QDialog,QCheckBox,QFrame)

class Spotlight(QDialog):
    """Search only known chebuOS apps; never invoke a shell command."""
    def __init__(self, shell):
        super().__init__(shell)
        self.shell=shell
        self.setWindowTitle('chebuSpotlight')
        self.resize(540,420)
        l=QVBoxLayout(self)
        l.addWidget(QLabel('🔎 chebuSpotlight — приложения'))
        self.entry=QLineEdit(); self.entry.setPlaceholderText('Название приложения…')
        l.addWidget(self.entry)
        self.results=QListWidget(); l.addWidget(self.results)
        self.entry.textChanged.connect(self.refresh)
        self.entry.returnPressed.connect(self.open_current)
        self.results.itemDoubleClicked.connect(lambda _:self.open_current())
        self.refresh('')
    def refresh(self,query=''):
        self.results.clear()
        for name in sorted(self.shell.apps,key=str.casefold):
            if query.casefold() in name.casefold():self.results.addItem(name)
        if self.results.count():self.results.setCurrentRow(0)
    def open_current(self):
        item=self.results.currentItem()
        if item:
            name=item.text();self.accept();self.shell.launch(name)
    def launch_search(self):
        self.entry.clear();self.refresh('');self.entry.setFocus();self.show();self.raise_();self.activateWindow()

class SafeTerminal(QWidget):
    """Chebu terminal: no arbitrary Python, PowerShell, bash, or subprocess."""
    def __init__(self,shell):
        super().__init__(); self.shell=shell
        l=QVBoxLayout(self)
        l.addWidget(QLabel('chebuTerminal • встроенные безопасные команды (это не PowerShell)'))
        self.output=QTextEdit();self.output.setReadOnly(True);self.output.setStyleSheet('font-family:Consolas,monospace;')
        l.addWidget(self.output)
        self.entry=QLineEdit();self.entry.setPlaceholderText('help');l.addWidget(self.entry)
        self.entry.returnPressed.connect(self.run_command)
        self.output.append('Добро пожаловать! Введи help.')
    def run_command(self):
        raw=self.entry.text().strip();self.entry.clear()
        if not raw:return
        self.output.append('> '+raw)
        cmd,*rest=raw.split(maxsplit=1)
        cmd=cmd.lower()
        arg=rest[0].strip() if rest else ''
        if cmd in ('help','?'):
            result='Команды: help, date, time, version, apps, open <приложение>, profile, desktop, clear, echo <текст>'
        elif cmd=='clear':
            self.output.clear();return
        elif cmd=='date':result=datetime.datetime.now().strftime('%d.%m.%Y')
        elif cmd=='time':result=datetime.datetime.now().strftime('%H:%M:%S')
        elif cmd=='version':result='chebuOS 1.6 NovaDesk'
        elif cmd=='apps':result=', '.join(sorted(self.shell.apps,key=str.casefold))
        elif cmd=='profile':result=self.shell.profile
        elif cmd=='desktop':result=str(self.shell.workspace+1)+' / 3'
        elif cmd=='echo':result=arg[:500]
        elif cmd=='open':
            match=next((n for n in self.shell.apps if n.casefold()==arg.casefold()),None)
            if match:
                self.shell.launch(match);result='Открываю '+match
            else:result='Такого приложения нет.'
        else:result='Команда недоступна. Введи help.'
        self.output.append(result)

class GameHub(QWidget):
    def __init__(self,shell):
        super().__init__();self.shell=shell
        l=QVBoxLayout(self)
        l.addWidget(QLabel('🎮 chebuGame Hub — библиотека игр'))
        l.addWidget(QLabel('Игры запускаются через Windows. Можно добавить свои ярлыки.'))
        self.list=QListWidget();l.addWidget(self.list)
        r=QHBoxLayout();l.addLayout(r)
        for label,fn in [('Запустить',self.play),('Добавить',self.add),('Удалить ярлык',self.remove),('Обновить',self.refresh)]:
            b=QPushButton(label);b.clicked.connect(fn);r.addWidget(b)
        self.list.itemDoubleClicked.connect(lambda _:self.play())
        self.refresh()
    def refresh(self):
        self.list.clear()
        for game in self.shell.game_links:self.list.addItem('🎮 '+game['name'])
    def add(self):
        # Reuse existing game's editor and refresh the hub on return.
        self.shell.launch('Мои игры')
    def play(self):
        idx=self.list.currentRow()
        if idx<0:return
        from extras import open_target
        open_target(self,self.shell.game_links[idx]['path'])
    def remove(self):
        idx=self.list.currentRow()
        if idx<0:return
        if QMessageBox.question(self,'Удалить ярлык','Убрать игру из списка? Файлы игры останутся на месте.')!=QMessageBox.StandardButton.Yes:return
        self.shell.game_links.pop(idx)
        self.shell.persist_games()
        self.refresh()

class LiveWidgets(QWidget):
    def __init__(self,shell):
        super().__init__();self.shell=shell
        l=QVBoxLayout(self)
        l.addWidget(QLabel('📊 Живые виджеты компьютера'))
        self.date=QLabel();self.stats=QLabel();self.stats.setWordWrap(True)
        l.addWidget(self.date);l.addWidget(self.stats)
        l.addWidget(QLabel('Обновление раз в 2 секунды. Данные о компьютере предоставляет psutil.'))
        l.addStretch()
        self.timer=QTimer(self);self.timer.timeout.connect(self.refresh);self.timer.start(2000);self.refresh()
    def refresh(self):
        self.date.setText(datetime.datetime.now().strftime('%d.%m.%Y  %H:%M:%S'))
        try:
            import psutil
            ram=psutil.virtual_memory()
            self.stats.setText(f'CPU: {psutil.cpu_percent(interval=None):.0f}%\nRAM: {ram.percent:.0f}%  ({ram.used/(1024**3):.1f} / {ram.total/(1024**3):.1f} ГБ)')
        except ImportError:
            self.stats.setText('Для данных CPU/RAM установи psutil.')

class Recovery(QWidget):
    """Back up chebuOS QSettings, not Windows, games, or personal files."""
    def __init__(self,shell):
        super().__init__();self.shell=shell
        l=QVBoxLayout(self)
        heading=QLabel('🛡 chebuRecovery — резервная копия настроек')
        l.addWidget(heading)
        desc=QLabel('Сохраняет настройки chebuOS текущего профиля: оформление, ярлыки, задачи. Не сохраняет файлы, игры, заметки и данные Windows.')
        desc.setWordWrap(True);l.addWidget(desc)
        for label,fn in [('Сохранить копию (.json)',self.backup),('Восстановить из копии',self.restore),('Сбросить расположение иконок',self.reset_icons)]:
            b=QPushButton(label);b.clicked.connect(fn);l.addWidget(b)
        l.addStretch()
    def backup(self):
        path,_=QFileDialog.getSaveFileName(self,'Сохранить резервную копию',str(Path.home()/'chebuOS-backup.json'),'JSON (*.json)')
        if not path:return
        try:
            data={key:self.shell.settings.value(key) for key in self.shell.settings.allKeys()}
            payload={'format':'chebuOS-settings-v1','profile':self.shell.profile,'settings':data}
            Path(path).write_text(json.dumps(payload,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
            QMessageBox.information(self,'Готово','Копия настроек сохранена.')
        except Exception as e:QMessageBox.warning(self,'Ошибка',str(e))
    def restore(self):
        path,_=QFileDialog.getOpenFileName(self,'Открыть копию',str(Path.home()),'JSON (*.json)')
        if not path:return
        try:
            if Path(path).stat().st_size>1024*1024:raise ValueError('Слишком большой файл резервной копии')
            data=json.loads(Path(path).read_text(encoding='utf-8'))
            if data.get('format')!='chebuOS-settings-v1' or not isinstance(data.get('settings'),dict):
                raise ValueError('Это не копия настроек chebuOS')
            vals=data['settings']
            if len(vals)>2000 or any(not isinstance(k,str) or len(k)>150 for k in vals):
                raise ValueError('Некорректные ключи настроек')
            if QMessageBox.question(self,'Восстановить?','Заменить настройки текущего профиля? Перезапусти chebuOS после восстановления.')!=QMessageBox.StandardButton.Yes:return
            self.shell.settings.clear()
            for key,value in vals.items():
                # Prevent malformed nested types from changing the settings schema.
                if isinstance(value,(str,bool,int,float,list)) or value is None:
                    self.shell.settings.setValue(key,value)
            self.shell.settings.sync()
            QMessageBox.information(self,'Готово','Настройки восстановлены. Перезапусти chebuOS.')
        except Exception as e:QMessageBox.warning(self,'Ошибка',str(e))
    def reset_icons(self):
        if QMessageBox.question(self,'Сбросить?','Сбросить расположение иконок?')!=QMessageBox.StandardButton.Yes:return
        self.shell.settings.remove('position');self.shell.update_icons()
