"""Extra local apps for chebuOS 1.4."""
import os
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, QSettings
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QPlainTextEdit, QSpinBox, QMessageBox, QCheckBox

class FocusTimer(QWidget):
    def __init__(self):
        super().__init__()
        self.remaining = 25*60
        self.running = False
        self.timer = QTimer(self)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self.tick)
        layout = QVBoxLayout(self)
        title=QLabel('chebuFocus — время для важных дел')
        title.setStyleSheet('font-size: 19px; font-weight: bold')
        layout.addWidget(title)
        layout.addWidget(QLabel('Установи минуты, нажми Старт и сосредоточься на задаче.'))
        controls=QHBoxLayout()
        layout.addLayout(controls)
        controls.addWidget(QLabel('Минут:'))
        self.minutes=QSpinBox()
        self.minutes.setRange(1,120)
        self.minutes.setValue(25)
        controls.addWidget(self.minutes)
        self.display=QLabel('25:00')
        self.display.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.display.setStyleSheet('font-size: 55px; font-weight: bold; color: #65E4C2; padding: 24px')
        layout.addWidget(self.display)
        buttons=QHBoxLayout()
        layout.addLayout(buttons)
        start=QPushButton('▶ Старт / Пауза')
        reset=QPushButton('↺ Сброс')
        buttons.addWidget(start);buttons.addWidget(reset)
        start.clicked.connect(self.toggle)
        reset.clicked.connect(self.reset)
        layout.addWidget(QLabel('Таймер работает, пока открыто это окно.'))
        layout.addStretch()
    def update_display(self):
        self.display.setText(f'{self.remaining//60:02d}:{self.remaining%60:02d}')
    def toggle(self):
        if self.running:
            self.running=False
            self.timer.stop()
        else:
            if self.remaining <= 0: self.reset()
            self.running=True
            self.timer.start()
    def reset(self):
        self.timer.stop()
        self.running=False
        self.remaining=self.minutes.value()*60
        self.update_display()
    def tick(self):
        self.remaining=max(0,self.remaining-1)
        self.update_display()
        if self.remaining==0:
            self.running=False
            self.timer.stop()
            QMessageBox.information(self,'chebuFocus','Готово! Время сделать перерыв. 🌟')

class StickyNotes(QWidget):
    def __init__(self):
        super().__init__()
        self.settings=QSettings('chebuOS','StickyNotes')
        layout=QVBoxLayout(self)
        title=QLabel('chebuNotes — быстрые заметки')
        title.setStyleSheet('font-size: 19px; font-weight: bold')
        layout.addWidget(title)
        layout.addWidget(QLabel('Текст сохраняется автоматически на этом компьютере.'))
        self.editor=QPlainTextEdit()
        self.editor.setPlaceholderText('Идеи, планы, домашние задания…')
        self.editor.setPlainText(self.settings.value('note','',type=str))
        layout.addWidget(self.editor)
        self.autosave=QTimer(self)
        self.autosave.setSingleShot(True)
        self.autosave.setInterval(400)
        self.autosave.timeout.connect(self.save)
        self.editor.textChanged.connect(self.autosave.start)
        row=QHBoxLayout()
        layout.addLayout(row)
        b=QPushButton('Сохранить сейчас');b.clicked.connect(self.save);row.addWidget(b)
        clear=QPushButton('Очистить');clear.clicked.connect(self.clear);row.addWidget(clear)
    def save(self):
        self.settings.setValue('note',self.editor.toPlainText())
        self.settings.sync()
    def clear(self):
        if QMessageBox.question(self,'chebuNotes','Очистить все заметки?') == QMessageBox.StandardButton.Yes:
            self.editor.clear()
            self.save()
    def closeEvent(self,event):
        self.save()
        super().closeEvent(event)
