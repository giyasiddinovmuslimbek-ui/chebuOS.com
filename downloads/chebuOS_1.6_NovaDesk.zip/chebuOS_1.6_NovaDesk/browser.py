import sys
from pathlib import Path
from urllib.parse import urlencode
from PySide6.QtCore import QUrl, Qt
from PySide6.QtGui import QShortcut, QKeySequence, QIcon
from PySide6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLineEdit, QTabWidget, QProgressBar
from PySide6.QtWebEngineWidgets import QWebEngineView

class Browser(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle('chebuBrowser 0.3'); self.setWindowIcon(QIcon(str(Path(__file__).parent/'assets'/'browser.png'))); self.resize(1200,800)
        root=QWidget(); self.setCentralWidget(root); layout=QVBoxLayout(root); nav=QHBoxLayout(); layout.addLayout(nav)
        for label,fn in [('←',lambda:self.current().back()),('→',lambda:self.current().forward()),('⟳',lambda:self.current().reload()),('⌂',lambda:self.current().setUrl(QUrl('https://www.google.com'))),('+',lambda:self.add_tab())]:
            b=QPushButton(label); b.clicked.connect(fn); nav.addWidget(b)
        self.address=QLineEdit(); self.address.setPlaceholderText('Поиск или адрес сайта'); self.address.returnPressed.connect(self.navigate); nav.addWidget(self.address,1)
        self.progress=QProgressBar(); self.progress.setRange(0,100); self.progress.setTextVisible(False); self.progress.setFixedHeight(3); layout.addWidget(self.progress); self.progress.hide()
        self.tabs=QTabWidget(); self.tabs.setTabsClosable(True); self.tabs.setMovable(True); layout.addWidget(self.tabs,1); self.tabs.tabCloseRequested.connect(self.close_tab); self.tabs.currentChanged.connect(self.sync)
        for key,fn in [('Ctrl+T',self.add_tab),('Ctrl+L',self.focus_address),('Ctrl+W',lambda:self.close_tab(self.tabs.currentIndex())),('Ctrl+R',lambda:self.current().reload())]:
            shortcut=QShortcut(QKeySequence(key),self); shortcut.activated.connect(fn)
        self.setStyleSheet('QMainWindow,QWidget{background:#141c2b;color:#e9f4ff;font-size:14px} QPushButton,QLineEdit{background:#24364a;border:1px solid #42566b;border-radius:8px;padding:9px} QPushButton:hover{border-color:#65e4c2} QTabBar::tab{background:#24364a;padding:10px} QTabBar::tab:selected{background:#37566b} QProgressBar::chunk{background:#65e4c2}')
        self.add_tab()
    def current(self): return self.tabs.currentWidget()
    def focus_address(self): self.address.setFocus(); self.address.selectAll()
    def add_tab(self):
        view=QWebEngineView(); i=self.tabs.addTab(view,'Новая вкладка'); self.tabs.setCurrentIndex(i)
        view.titleChanged.connect(lambda title:self.tabs.setTabText(self.tabs.indexOf(view),title[:35] or 'Вкладка') if self.tabs.indexOf(view)>=0 else None)
        view.urlChanged.connect(lambda url:self.address.setText(url.toString()) if self.current() is view else None)
        view.loadProgress.connect(lambda n:self.loading(view,n)); view.loadFinished.connect(lambda ok:self.loading(view,100)); view.setUrl(QUrl('https://www.google.com')); self.focus_address()
    def loading(self,view,n):
        if self.current() is view: self.progress.setValue(n); self.progress.setVisible(n<100)
    def sync(self,i):
        if self.current(): self.address.setText(self.current().url().toString()); self.progress.hide()
    def close_tab(self,i):
        if i<0:return
        if self.tabs.count()==1: self.current().setUrl(QUrl('https://www.google.com')); return
        view=self.tabs.widget(i); self.tabs.removeTab(i); view.deleteLater()
    def navigate(self):
        text=self.address.text().strip()
        if not text:return
        if text.startswith(('https://','http://')): url=QUrl(text)
        elif ' ' not in text and ('.' in text or text.startswith('localhost')): url=QUrl.fromUserInput(text)
        else: url=QUrl('https://www.google.com/search?'+urlencode({'q':text}))
        if url.scheme() in ('http','https'): self.current().setUrl(url)

if __name__=='__main__':
    app=QApplication(sys.argv); window=Browser(); window.show(); sys.exit(app.exec())
