import os, json, shutil, uuid
from pathlib import Path
from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QMessageBox, QFileDialog, QInputDialog, QListWidget, QLabel

def open_target(parent, path):
    try:
        if not Path(path).is_file(): raise FileNotFoundError(path)
        if os.name == 'nt': os.startfile(path)
        elif not QDesktopServices.openUrl(QUrl.fromLocalFile(path)): raise RuntimeError('Не удалось открыть файл')
    except Exception as e: QMessageBox.warning(parent,'Запуск',str(e))

class Trash:
    def __init__(self, base):
        self.base=Path(base); self.base.mkdir(parents=True,exist_ok=True)
    def entries(self):
        result=[]
        for p in self.base.glob('*/info.json'):
            try:
                data=json.loads(p.read_text(encoding='utf-8')); target=p.parent/'payload'
                if target.exists() or target.is_symlink(): result.append((p.parent,data['original']))
            except (OSError,ValueError,KeyError): pass
        return result
    def put(self, path):
        p=Path(path).absolute()
        if not p.is_file() or p.is_symlink(): raise ValueError('Можно перемещать только обычные файлы')
        if self.base.resolve() in p.resolve().parents: raise ValueError('Файл уже в корзине')
        d=self.base/uuid.uuid4().hex; d.mkdir(); (d/'info.json').write_text(json.dumps({'original':str(p)},ensure_ascii=False),encoding='utf-8')
        try: shutil.move(str(p),str(d/'payload'))
        except Exception:
            if not (d/'payload').exists(): shutil.rmtree(d)
            raise
    def restore(self, folder, original):
        p=Path(original)
        if os.path.lexists(p): raise FileExistsError('Файл с таким именем уже существует')
        if not p.parent.is_dir(): raise FileNotFoundError('Исходная папка не существует')
        shutil.move(str(folder/'payload'),str(p)); shutil.rmtree(folder)
