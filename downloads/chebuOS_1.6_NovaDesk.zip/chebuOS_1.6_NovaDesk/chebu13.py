"""chebuOS 1.3 built-in apps. No privileged system operations."""
import os
import shutil
import random
import datetime
import subprocess
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, QUrl, QPoint, QSize
from PySide6.QtGui import QColor, QPainter, QPen, QImage, QPixmap, QDesktopServices
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFileDialog, QMessageBox, QListWidget, QLineEdit, QPlainTextEdit, QComboBox,
    QGridLayout, QSlider, QInputDialog, QFrame, QApplication)

APPDATA = Path(os.environ.get('LOCALAPPDATA') or str(Path.home())) / 'chebuOS'

def btn(text, func, layout):
    b=QPushButton(text); b.clicked.connect(func); layout.addWidget(b); return b

def local_cloud():
    """Explicitly local folder; not a remote cloud service."""
    base=APPDATA/'chebuDrive'
    base.mkdir(parents=True, exist_ok=True)
    return base

class Cloud(QWidget):
    def __init__(self):
        super().__init__(); self.folder=local_cloud(); outer=QVBoxLayout(self)
        outer.addWidget(QLabel('chebuDrive — локальное хранилище на этом компьютере'))
        outer.addWidget(QLabel('Файлы не загружаются в интернет. Это не облачная синхронизация.'))
        self.list=QListWidget(); outer.addWidget(self.list)
        row=QHBoxLayout(); outer.addLayout(row)
        btn('Добавить файл',self.add,row); btn('Открыть',self.open,row); btn('Удалить копию',self.delete,row); btn('Папка',self.show_folder,row)
        self.reload()
    def reload(self):
        self.list.clear()
        for p in sorted(self.folder.iterdir()):
            if p.is_file(): self.list.addItem(p.name)
    def selected(self):
        i=self.list.currentItem()
        return self.folder/i.text() if i else None
    def add(self):
        files,_=QFileDialog.getOpenFileNames(self,'Выбери файлы',str(Path.home()))
        for file in files:
            source=Path(file); dest=self.folder/source.name
            if dest.exists():
                QMessageBox.information(self,'chebuDrive',f'{dest.name} уже существует, пропускаем.'); continue
            try: shutil.copy2(source,dest)
            except OSError as e: QMessageBox.warning(self,'Ошибка копирования',str(e))
        self.reload()
    def open(self):
        p=self.selected()
        if p and p.is_file(): QDesktopServices.openUrl(QUrl.fromLocalFile(str(p)))
    def delete(self):
        p=self.selected()
        if not p: return
        if QMessageBox.question(self,'Подтверждение',f'Удалить локальную копию {p.name}?')==QMessageBox.StandardButton.Yes:
            try:p.unlink()
            except OSError as e: QMessageBox.warning(self,'Ошибка',str(e))
            self.reload()
    def show_folder(self): QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.folder)))

class Game(QWidget):
    def __init__(self):
        super().__init__(); layout=QVBoxLayout(self); layout.addWidget(QLabel('chebuArcade — Крестики-нолики'))
        self.label=QLabel('Ты играешь за X. Ход первым.'); layout.addWidget(self.label)
        grid=QGridLayout(); layout.addLayout(grid); self.cells=[]; self.done=False
        for i in range(9):
            b=QPushButton(''); b.setMinimumSize(70,70); b.setStyleSheet('font-size:30px;font-weight:bold;')
            b.clicked.connect(lambda checked=False,idx=i:self.move(idx)); grid.addWidget(b,i//3,i%3); self.cells.append(b)
        btn('Новая игра',self.reset,layout)
    def winner(self):
        a=[b.text() for b in self.cells]
        for t in ((0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)):
            if a[t[0]] and a[t[0]]==a[t[1]]==a[t[2]]: return a[t[0]]
        return 'draw' if all(a) else None
    def finish(self):
        winner=self.winner()
        if winner:
            self.done=True; self.label.setText({'X':'Ты победил! 🎉','O':'Компьютер победил','draw':'Ничья!'}[winner]); return True
        return False
    def move(self,i):
        if self.done or self.cells[i].text():return
        self.cells[i].setText('X')
        if self.finish():return
        empty=[j for j,b in enumerate(self.cells) if not b.text()]
        if empty:self.cells[random.choice(empty)].setText('O'); self.finish()
    def reset(self):
        for b in self.cells:b.setText('')
        self.done=False; self.label.setText('Ты играешь за X. Ход первым.')

class Assistant(QWidget):
    """Offline keyword helper; no external AI model or data transfer."""
    def __init__(self,launch=None):
        super().__init__(); self.launch=launch; l=QVBoxLayout(self)
        l.addWidget(QLabel('chebuAssistant — офлайн-помощник (без нейросети)'))
        l.addWidget(QLabel('Попробуй: время, дата, браузер, блокнот, игры, настройки, помощь'))
        self.messages=QPlainTextEdit(); self.messages.setReadOnly(True); l.addWidget(self.messages)
        r=QHBoxLayout();l.addLayout(r);self.input=QLineEdit();self.input.setPlaceholderText('Напиши команду…');r.addWidget(self.input)
        btn('Отправить',self.reply,r);self.input.returnPressed.connect(self.reply)
        self.messages.appendPlainText('chebuAssistant: Привет! Я помогу открыть приложения и ответить на простые команды.')
    def reply(self):
        raw=self.input.text().strip()
        if not raw:return
        self.input.clear();s=raw.casefold(); action=None
        if any(x in s for x in ['время','который час']): answer=datetime.datetime.now().strftime('Сейчас %H:%M:%S')
        elif 'дата' in s or 'число' in s:answer=datetime.datetime.now().strftime('Сегодня %d.%m.%Y')
        elif 'брауз' in s:answer='Открываю chebuBrowser';action='chebuBrowser'
        elif 'блокнот' in s:answer='Открываю Блокнот';action='Блокнот'
        elif 'игр' in s:answer='Открываю chebuArcade';action='chebuArcade'
        elif 'настрой' in s:answer='Открываю Настройки';action='Настройки'
        elif 'помощ' in s:answer='Доступные команды: время, дата, браузер, блокнот, игры, настройки.'
        else:answer='Я пока умею только простые офлайн-команды. Подсказка: напиши «помощь».'
        self.messages.appendPlainText(f'Ты: {raw}\nchebuAssistant: {answer}\n')
        if action and self.launch:QTimer.singleShot(0,lambda:self.launch(action))

class Video(QWidget):
    def __init__(self):
        super().__init__()
        from PySide6.QtMultimedia import QMediaPlayer,QAudioOutput
        from PySide6.QtMultimediaWidgets import QVideoWidget
        self.player=QMediaPlayer(self); self.audio=QAudioOutput(self); self.player.setAudioOutput(self.audio)
        l=QVBoxLayout(self); l.addWidget(QLabel('chebuVideo — локальные видеофайлы'))
        self.video=QVideoWidget(self);self.video.setMinimumSize(450,250);self.player.setVideoOutput(self.video);l.addWidget(self.video,1)
        self.status=QLabel('Выбери видео для воспроизведения');l.addWidget(self.status)
        r=QHBoxLayout();l.addLayout(r)
        btn('Открыть',self.open,r);btn('▶ Играть',self.player.play,r);btn('Пауза',self.player.pause,r);btn('Стоп',self.player.stop,r)
        self.seek=QSlider(Qt.Orientation.Horizontal);l.addWidget(self.seek)
        self.player.durationChanged.connect(lambda duration:self.seek.setRange(0,duration))
        self.player.positionChanged.connect(self.seek.setValue);self.seek.sliderMoved.connect(self.player.setPosition)
        self.player.errorOccurred.connect(lambda *_:self.status.setText(self.player.errorString()))
    def open(self):
        name,_=QFileDialog.getOpenFileName(self,'Открыть видео',str(Path.home()),'Видео (*.mp4 *.mkv *.mov *.avi *.webm);;Все файлы (*)')
        if name:self.player.setSource(QUrl.fromLocalFile(name)); self.status.setText(Path(name).name);self.player.play()
    def closeEvent(self,event):self.player.stop();super().closeEvent(event)

class Screenshots(QWidget):
    def __init__(self):
        super().__init__(); l=QVBoxLayout(self)
        l.addWidget(QLabel('chebuShot — снимок экрана с сохранением в PNG'))
        l.addWidget(QLabel('Перед снимком можешь свернуть окно chebuOS.'))
        btn('Сделать скриншот через 3 секунды',self.shoot,l)
        self.info=QLabel('Файл будет сохранён в выбранную папку.');l.addWidget(self.info);l.addStretch()
    def shoot(self):
        self.info.setText('Снимок через 3 секунды…');QTimer.singleShot(3000,self.capture)
    def capture(self):
        screen=QApplication.primaryScreen()
        if screen is None:self.info.setText('Экран не найден');return
        pix=screen.grabWindow(0)
        name,_=QFileDialog.getSaveFileName(self,'Сохранить скриншот',str(Path.home()/('chebuShot_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.png')),'PNG (*.png)')
        if name:self.info.setText('Снимок сохранён' if pix.save(name,'PNG') else 'Не удалось сохранить снимок')

class PaintArea(QWidget):
    def __init__(self):
        super().__init__(); self.setMinimumSize(460,290); self.canvas=QImage(900,540,QImage.Format.Format_ARGB32);self.canvas.fill(QColor('white'));self.last=None;self.color=QColor('#0e8ed6');self.brush=5
    def paintEvent(self,e):
        p=QPainter(self);p.fillRect(self.rect(),Qt.GlobalColor.white);p.drawImage(self.rect(),self.canvas)
    def mousePressEvent(self,e):
        if e.button()==Qt.MouseButton.LeftButton:self.last=self.point(e.position().toPoint());self.line(self.last,self.last)
    def mouseMoveEvent(self,e):
        if self.last is not None:
            point=self.point(e.position().toPoint());self.line(self.last,point);self.last=point
    def mouseReleaseEvent(self,e):self.last=None
    def point(self,p):return QPoint(int(p.x()*self.canvas.width()/max(1,self.width())),int(p.y()*self.canvas.height()/max(1,self.height())))
    def line(self,p,q):
        painter=QPainter(self.canvas); painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        pen=QPen(self.color,self.brush,Qt.PenStyle.SolidLine,Qt.PenCapStyle.RoundCap,Qt.PenJoinStyle.RoundJoin)
        painter.setPen(pen);painter.drawLine(p,q);painter.end();self.update()

class Paint(QWidget):
    def __init__(self):
        super().__init__();l=QVBoxLayout(self);l.addWidget(QLabel('chebuPaint — рисуй мышкой'))
        self.area=PaintArea();l.addWidget(self.area,1)
        row=QHBoxLayout();l.addLayout(row)
        for label,color in [('Синий','#0e8ed6'),('Чёрный','#202638'),('Зелёный','#20b981'),('Красный','#eb5063'),('Ластик','#ffffff')]:
            btn(label,lambda c=color:self.set_color(c),row)
        btn('Очистить',self.clear,row);btn('Сохранить PNG',self.save,row)
        row2=QHBoxLayout();l.addLayout(row2);row2.addWidget(QLabel('Толщина кисти:'))
        size=QSlider(Qt.Orientation.Horizontal);size.setRange(2,35);size.setValue(5);size.valueChanged.connect(lambda v:setattr(self.area,'brush',v));row2.addWidget(size)
    def set_color(self,color):self.area.color=QColor(color)
    def clear(self):self.area.canvas.fill(Qt.GlobalColor.white);self.area.update()
    def save(self):
        name,_=QFileDialog.getSaveFileName(self,'Сохранить рисунок',str(Path.home()/'chebuDrawing.png'),'PNG (*.png)')
        if name and not self.area.canvas.save(name,'PNG'):QMessageBox.warning(self,'Ошибка','Не удалось сохранить файл')

class Monitor(QWidget):
    def __init__(self):
        super().__init__();l=QVBoxLayout(self);l.addWidget(QLabel('chebuMonitor — нагрузка Windows'))
        self.cpu=QLabel();self.ram=QLabel();self.disk=QLabel()
        for w in (self.cpu,self.ram,self.disk):w.setStyleSheet('font-size:19px;padding:12px;');l.addWidget(w)
        l.addStretch();self.timer=QTimer(self);self.timer.timeout.connect(self.update_values);self.timer.start(1800);self.update_values()
    def update_values(self):
        try:
            import psutil
            self.cpu.setText(f'CPU: {psutil.cpu_percent(interval=None):.1f}%')
            mem=psutil.virtual_memory();self.ram.setText(f'RAM: {mem.percent:.1f}% ({mem.used/1024**3:.1f} / {mem.total/1024**3:.1f} ГБ)')
            disk=psutil.disk_usage(str(Path.home().anchor or '/'))
            self.disk.setText(f'Диск: {disk.percent:.1f}% занято')
        except ImportError:self.cpu.setText('Для мониторинга требуется psutil');self.timer.stop()
        except Exception as e:self.cpu.setText(f'Нет данных: {e}')

class LockScreen(QWidget):
    """Visual in-app lock, NOT Windows authentication or security boundary."""
    def __init__(self):
        super().__init__();l=QVBoxLayout(self);l.addStretch()
        title=QLabel('🔒 chebuOS');title.setAlignment(Qt.AlignmentFlag.AlignCenter);title.setStyleSheet('font-size:38px;font-weight:bold;');l.addWidget(title)
        self.clock=QLabel();self.clock.setAlignment(Qt.AlignmentFlag.AlignCenter);self.clock.setStyleSheet('font-size:26px');l.addWidget(self.clock)
        subtitle=QLabel('Экран блокировки chebuOS (не блокировка Windows)');subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter);l.addWidget(subtitle)
        b=QPushButton('Разблокировать');b.setMinimumHeight(52);b.clicked.connect(self.close);l.addWidget(b)
        l.addStretch();self.timer=QTimer(self);self.timer.timeout.connect(self.tick);self.timer.start(1000);self.tick()
    def tick(self):self.clock.setText(datetime.datetime.now().strftime('%H:%M:%S · %d.%m.%Y'))
