chebuOS 1.3 Creative — Windows
=================================

УСТАНОВКА
1. Установите Python 3.12 (64-bit) или новее.
2. Распакуйте ZIP в отдельную папку (не запускайте внутри архива).
3. Запустите START.bat. При первом запуске нужен интернет.
4. Выберите профиль, затем откройте новые приложения через «Пуск».

НОВОЕ В 1.3
- chebuDrive — ЛОКАЛЬНАЯ папка для копий файлов. Нет синхронизации с интернетом.
- chebuArcade — крестики-нолики против компьютера.
- chebuAssistant — офлайн-команды, а НЕ генеративная нейросеть.
- chebuVideo — местный видеоплеер; кодеки зависят от Qt и системы.
- chebuShot — скриншоты PNG (через 3 секунды, основной экран).
- Экран блокировки — декоративная блокировка окна, НЕ защита Windows.
- chebuPaint — рисование и сохранение PNG.
- chebuMonitor — CPU, RAM, диск (psutil).

ПРЕЖНИЕ ФУНКЦИИ СОХРАНЕНЫ
Встроенный chebuBrowser, Telegram Web, корзина chebuOS, игры и ярлыки,
файловый менеджер, блокнот, музыка, обои, профили, chebuStore и др.

БЕЗОПАСНОСТЬ И ДАННЫЕ
Не удаляйте предыдущую рабочую версию, пока не проверите эту.
Настройки пользователя хранятся через QSettings. chebuDrive и Корзина
расположены внутри LOCALAPPDATA/chebuOS. При выборе «Удалить копию»
в chebuDrive файл удаляется из chebuDrive, а оригинал остаётся на месте.
chebuOS — графическая оболочка Windows, не самостоятельная ОС.
Проверен синтаксис и состав пакета; GUI на Windows требует проверки.

NEW 1.4 GALAXY: chebuFocus (timer), chebuNotes (autosaved notes), Galaxy wallpaper from user-provided artwork. Access via Start menu or app search (Ctrl+K).


Version 1.5 Visual Start
This build adds a tile-based Start launcher with icons and improved chebuOS branding.
