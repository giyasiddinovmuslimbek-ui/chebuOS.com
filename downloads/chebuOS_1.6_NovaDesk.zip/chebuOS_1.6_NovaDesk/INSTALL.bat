@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe py -3 -m venv .venv
if errorlevel 1 goto error
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto error
.venv\Scripts\python.exe -c "from PySide6.QtWidgets import QApplication; from PySide6.QtWebEngineWidgets import QWebEngineView"
if errorlevel 1 goto error
echo Installation complete. Run START.bat to open chebuOS.
pause
exit /b 0
:error
echo Installation failed. Check the error above.
pause
exit /b 1
